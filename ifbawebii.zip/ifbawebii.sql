-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25-Jan-2025 às 00:43
-- Versão do servidor: 10.4.21-MariaDB
-- versão do PHP: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `ifbawebii`
--
CREATE DATABASE IF NOT EXISTS `ifbawebii` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ifbawebii`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `cod_produto` int(10) NOT NULL,
  `desc_produto` varchar(100) NOT NULL,
  `valor_produto` float NOT NULL,
  `quantidade_estoque` int(11) NOT NULL,
  `imagem_produto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`cod_produto`, `desc_produto`, `valor_produto`, `quantidade_estoque`, `imagem_produto`) VALUES
(1, 'Produto 1', 10, 10, '1.jpg'),
(2, 'Produto 2', 20, 20, '2.jpg'),
(3, 'Produto 3', 30, 30, '3.jpg'),
(4, 'Produto 4', 40, 40, '4.jpg'),
(5, 'Produto 5', 50, 50, '5.jpg'),
(6, 'Produto 6', 60, 60, '6.jpg'),
(7, 'Produto 7', 70, 70, '7.jpg'),
(8, 'Produto 8', 80, 80, '8.jpg'),
(9, 'Produto 9', 90, 90, '9.jpg'),
(10, 'Produto 10', 100, 100, '10.jpg');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`cod_produto`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `cod_produto` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
